=== WP Multibyte Patch ===
Contributors: tenpura
Tags: multibyte,i18n,wp-multibyte-patch,Japanese
Requires at least: 4.5
Tested up to: 5.4
Stable tag: 2.8.4

Multibyte functionality enhancement for the WordPress Japanese package.

== Description ==

Multibyte functionality enhancement for the WordPress Japanese package.
[日本語の説明を読む](https://eastcoder.com/code/wp-multibyte-patch/ "Documentation in Japanese")

== Installation ==

1. Upload the `wp-multibyte-patch` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the Plugins menu in WordPress.
